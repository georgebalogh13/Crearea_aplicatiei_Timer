import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static java.awt.Frame.NORMAL;

public class Timer {

    public static void main(String[] args){

        JFrame f = new JFrame("Option dialog");
        f.setSize(500, 300);
        f.setVisible(true);
        f.setLayout(null);
        JLabel l1 = new JLabel("Choose option");
        l1.setBounds(150, 120, 250, 30);
        f.add(l1);
        JButton b1 = new JButton("Settings");
        JButton b2 = new JButton("Close");
        b1.setBounds(150,150, 100, 30);
        b2.setBounds(300, 150, 100,30);
        f.add(b1);
        f.add(b2);
        ImageIcon ii = new ImageIcon("C:\\java_programs\\Timer\\src\\question.png");

        JLabel lbl = new JLabel(ii);
        lbl.setText("question");
        lbl.setFont(new Font("Verdana", NORMAL, 35));
        lbl.setBounds(50,50,70,70);
        f.add(lbl);
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JFrame f1 = new JFrame();
        f1.setSize(500, 300);
        f1.setVisible(false);
        f1.setLayout(null);

        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f1.setVisible(true);
            }
        });

        JRadioButton r1 = new JRadioButton("on time:");
        JRadioButton r2 = new JRadioButton("countdown (sec):");
        r1.setBounds(10,10,150,30);
        r2.setBounds(10,55,150,30);
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        f1.add(r1);
        f1.add(r2);

        JTextField t1 = new JTextField();
        t1.setBounds(250,10,200,30);
        f1.add(t1);
        JTextField t2 = new JTextField();
        t2.setBounds(250,55,200,30);
        f1.add(t2);

        JButton b3 = new JButton("Choose color");
        b3.setBounds(150,150, 200, 30);
        f1.add(b3);

        Color newColor = Color.RED;
        Color[] color = {newColor};
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                color[0] = JColorChooser.showDialog(null, "Choose a color", Color.RED);
            }
        });
        JComboBox jcb1 = new JComboBox();
        jcb1.addItem("1");
        jcb1.addItem("2");
        jcb1.addItem("3");
        jcb1.addItem("4");
        jcb1.addItem("5");
        jcb1.setBounds(150,180, 200, 30);
        f1.add(jcb1);

        JLabel lb1 = new JLabel("speed");
        lb1.setBounds(80,180, 60, 30);
        f1.add(lb1);

        JButton b4 = new JButton("Start Countdown");
        b4.setBounds(150,220, 150, 30);
        f1.add(b4);

        JButton b5 = new JButton("Stop");
        b5.setBounds(350,220, 100, 30);
        f1.add(b5);

        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                b3.setEnabled(false);
                b4.setEnabled(false);
                jcb1.setEnabled(false);
                if (t1.getText().length() > 0){
                    String time = t1.getText();
                    int hours = Integer.parseInt(time.substring(0, 2));
                    int minutes = Integer.parseInt(time.substring(3, 5));
                    int seconds = Integer.parseInt(time.substring(6, 8));
                    System.out.println(hours);
                    System.out.println(minutes);
                    System.out.println(seconds);
                    int final_time = hours*60*60 + minutes*60 + seconds;
                    int speed = jcb1.getSelectedIndex() + 1;
                    System.out.println(speed);
                    ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();
                    int [] timeArray = {
                            final_time
                    };
                    JFrame f2 = new JFrame();
                    f2.getContentPane().setBackground(color[0]);
                    int[] colorCount = {0};
                    ScheduledExecutorService exec1 = Executors.newSingleThreadScheduledExecutor();
                    Runnable colorChange = new Runnable() {
                        @Override
                        public void run() {
                            if (colorCount[0] % 2 == 0){
                                f2.getContentPane().setBackground(color[0]);
                            } else f2.getContentPane().setBackground(Color.WHITE);
                            colorCount[0]++;
                        }
                    };
                    exec1.scheduleAtFixedRate(colorChange, 0, speed, TimeUnit.SECONDS);
                    Runnable thread = new Runnable() {
                        @Override
                        public void run() {
                            timeArray[0] --;
                            System.out.println(timeArray[0]);
                            if (timeArray[0] == 0){
                                exec.shutdown();
                                f2.setBounds(550, 200, 500, 500);
                                f2.setVisible(true);
                            }
                        }
                    };
                    exec.scheduleAtFixedRate(thread, 0, 1, TimeUnit.SECONDS);
                    b5.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            exec.shutdown();
                            f2.setVisible(false);
                        }
                    });
                }
                else{
                    System.out.println(t2.getText());
                    int timeSeconds = Integer.parseInt(t2.getText());
                    int speed = jcb1.getSelectedIndex() + 1;
                    System.out.println(speed);
                    int [] timeArray = {
                            timeSeconds
                    };
                    ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();
                    JFrame f2 = new JFrame();
                    f2.getContentPane().setBackground(color[0]);
                    int[] colorCount = {0};
                    ScheduledExecutorService exec1 = Executors.newSingleThreadScheduledExecutor();
                    Runnable colorChange = new Runnable() {
                        @Override
                        public void run() {
                            if (colorCount[0] % 2 == 0){
                                f2.getContentPane().setBackground(color[0]);
                            } else f2.getContentPane().setBackground(Color.WHITE);
                            colorCount[0]++;
                        }
                    };
                    exec1.scheduleAtFixedRate(colorChange, 0, speed, TimeUnit.SECONDS);
                    Runnable thread2 = new Runnable() {
                        @Override
                        public void run() {
                            timeArray[0] --;
                            System.out.println(timeArray[0]);
                            if (timeArray[0] == 0){
                                exec.shutdown();
                                f2.setBounds(550, 200, 500, 500);
                                f2.setVisible(true);
                        }
                    }
                };
                    exec.scheduleAtFixedRate(thread2, 0, 1, TimeUnit.SECONDS);
                    b5.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            exec.shutdown();
                            f2.setVisible(false);
                        }
                    });
            }
        }});
    }
}




